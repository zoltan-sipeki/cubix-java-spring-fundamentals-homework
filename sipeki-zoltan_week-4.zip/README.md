# cubix-homework-week-1
homework week 1
