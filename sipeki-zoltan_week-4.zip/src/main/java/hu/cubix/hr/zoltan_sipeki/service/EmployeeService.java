package hu.cubix.hr.zoltan_sipeki.service;

import hu.cubix.hr.zoltan_sipeki.model.Employee;

public interface EmployeeService {
	int getPayRaisePercent(Employee employee);
}
